oauth2client.contrib.keyring_storage module
===========================================

.. automodule:: oauth2client.contrib.keyring_storage
    :members:
    :undoc-members:
    :show-inheritance:
