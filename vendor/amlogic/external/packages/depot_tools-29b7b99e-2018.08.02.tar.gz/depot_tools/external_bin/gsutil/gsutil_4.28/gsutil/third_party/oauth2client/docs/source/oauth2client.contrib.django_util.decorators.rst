oauth2client.contrib.django_util.decorators module
==================================================

.. automodule:: oauth2client.contrib.django_util.decorators
    :members:
    :undoc-members:
    :show-inheritance:
